const rollButton = document.getElementById('roll');
const result = document.getElementById('result');

rollButton.addEventListener('click', () => {
  const number = Math.floor(Math.random() * 6) + 1;
  result.textContent = `You rolled: ${number} 🎲`;
});
